"""
FilterMate User Feedback Utilities

This module provides standardized user feedback messages with backend awareness
and consistent formatting for QGIS message bar notifications.

Usage:
    from modules.feedback_utils import show_backend_info, show_progress_message
    
    show_backend_info('postgresql', layer_count=5)
    show_progress_message('Filtering layers', progress=3, total=10)
"""
from typing import Optional

from qgis.core import Qgis

try:
    from config.feedback_config import should_show_message
except ImportError:
    # Fallback if config module not available
    def should_show_message(category):
        return True  # Show all messages by default


# =============================================================================
# Generic Feedback Functions (for centralized message bar access)
# =============================================================================

def show_info(message: str, title: str = "FilterMate"):
    """
    Show an info message in the QGIS message bar.
    
    Args:
        message: The message to display
        title: The message title (default: "FilterMate")
    
    Example:
        >>> show_info("Operation completed successfully")
    """
    try:
        from qgis.utils import iface
        if iface and should_show_message('info'):
            iface.messageBar().pushInfo(title, message)
    except Exception:
        pass  # Graceful fallback if iface not available


def show_warning(message: str, title: str = "FilterMate"):
    """
    Show a warning message in the QGIS message bar.
    
    Args:
        message: The message to display
        title: The message title (default: "FilterMate")
    
    Example:
        >>> show_warning("Large dataset detected. Performance may be reduced.")
    """
    try:
        from qgis.utils import iface
        if iface and should_show_message('warning'):
            iface.messageBar().pushWarning(title, message)
    except Exception:
        pass  # Graceful fallback if iface not available


def show_error(message: str, title: str = "FilterMate"):
    """
    Show an error message in the QGIS message bar.
    
    Args:
        message: The message to display
        title: The message title (default: "FilterMate")
    
    Example:
        >>> show_error("Failed to apply filter: connection refused")
    """
    try:
        from qgis.utils import iface
        if iface and should_show_message('error'):
            iface.messageBar().pushCritical(title, message)
    except Exception:
        pass  # Graceful fallback if iface not available


def show_success(message: str, title: str = "FilterMate"):
    """
    Show a success message in the QGIS message bar.
    
    Args:
        message: The message to display
        title: The message title (default: "FilterMate")
    
    Example:
        >>> show_success("Filter applied successfully")
    """
    try:
        from qgis.utils import iface
        if iface and should_show_message('success'):
            iface.messageBar().pushSuccess(title, message)
    except Exception:
        pass  # Graceful fallback if iface not available


# Backend display names and icons
BACKEND_INFO = {
    'postgresql': {
        'name': 'PostgreSQL',
        'icon': '🐘',
        'description': 'High-performance database backend',
        'color': '#336791'
    },
    'spatialite': {
        'name': 'Spatialite',
        'icon': '💾',
        'description': 'File-based database backend',
        'color': '#4A90E2'
    },
    'ogr': {
        'name': 'OGR',
        'icon': '📁',
        'description': 'File-based data source',
        'color': '#7CB342'
    },
    'memory': {
        'name': 'Memory',
        'icon': '⚡',
        'description': 'Temporary in-memory layer',
        'color': '#FFA000'
    }
}


def get_backend_display_name(provider_type):
    """
    Get user-friendly display name for backend.
    
    Args:
        provider_type (str): Backend type ('postgresql', 'spatialite', 'ogr', etc.)
    
    Returns:
        str: Display name with icon (e.g., '🐘 PostgreSQL')
    """
    backend = BACKEND_INFO.get(provider_type.lower(), {
        'name': provider_type.title(),
        'icon': '❓',
        'description': 'Unknown backend',
        'color': '#757575'
    })
    return f"{backend['icon']} {backend['name']}"


def show_backend_info(provider_type, layer_count=1, operation='filter', is_fallback=False):
    """
    Show informational message about which backend is being used.
    
    Args:
        provider_type (str): Backend type ('postgresql', 'spatialite', 'ogr')
        layer_count (int): Number of layers being processed
        operation (str): Operation type ('filter', 'export', 'reset')
        is_fallback (bool): True if using OGR as fallback (for PostgreSQL without connection
                           or Spatialite without Spatialite extension in GDAL)
    
    Example:
        >>> show_backend_info('postgresql', layer_count=5)
        # Shows: "FilterMate - 🐘 PostgreSQL: Starting filter on 5 layer(s)..."
    """
    try:
        from qgis.utils import iface
        backend_name = get_backend_display_name(provider_type)
        
        operation_text = {
            'filter': f"Starting filter on {layer_count} layer(s)",
            'unfilter': f"Removing filters from {layer_count} layer(s)",
            'reset': f"Resetting {layer_count} layer(s)",
            'export': f"Exporting {layer_count} layer(s)"
        }.get(operation, f"Processing {layer_count} layer(s)")
        
        # Add fallback indicator for layers using OGR
        if is_fallback:
            message = f"📦 OGR (fallback): {operation_text}..."
        else:
            message = f"{backend_name}: {operation_text}..."
        
        if iface and should_show_message('backend_info'):
            iface.messageBar().pushInfo("FilterMate", message)
    except Exception:
        pass


def show_progress_message(message: str, current: Optional[int] = None,
                          total: Optional[int] = None):
    """
    Show progress message for long operations.
    
    Args:
        message (str): Operation description (e.g., 'Filtering layers')
        current (int, optional): Current item number
        total (int, optional): Total number of items
    
    Example:
        >>> show_progress_message('Filtering layers', current=3, total=10)
        # Shows: "FilterMate: Filtering layers (3/10)..."
    """
    try:
        from qgis.utils import iface
        if current is not None and total is not None:
            full_message = f"{message} ({current}/{total})..."
        else:
            full_message = f"{message}..."
        
        if iface and should_show_message('progress_info'):
            iface.messageBar().pushInfo("FilterMate", full_message)
    except Exception:
        pass


def show_success_with_backend(provider_type: str, operation: str = 'filter',
                              layer_count: int = 1, is_fallback: bool = False):
    """
    Show success message with backend information.
    
    Args:
        provider_type (str): Backend type
        operation (str): Operation type
        layer_count (int): Number of layers processed
        is_fallback (bool): True if using OGR as fallback (for PostgreSQL without connection
                           or Spatialite without Spatialite extension in GDAL)
    
    Example:
        >>> show_success_with_backend('postgresql', 'filter', layer_count=5)
        # Shows: "FilterMate - 🐘 PostgreSQL: Successfully filtered 5 layer(s)"
        >>> show_success_with_backend('ogr', 'filter', layer_count=5, is_fallback=True)
        # Shows: "FilterMate - 📦 OGR (fallback): Successfully filtered 5 layer(s)"
    """
    try:
        from qgis.utils import iface
        backend_name = get_backend_display_name(provider_type)
        
        operation_text = {
            'filter': f"Successfully filtered {layer_count} layer(s)",
            'unfilter': f"Successfully removed filters from {layer_count} layer(s)",
            'reset': f"Successfully reset {layer_count} layer(s)",
            'export': f"Successfully exported {layer_count} layer(s)"
        }.get(operation, f"Successfully processed {layer_count} layer(s)")
        
        # Add fallback indicator for layers using OGR as fallback
        if is_fallback:
            message = f"📦 OGR (fallback): {operation_text}"
        else:
            message = f"{backend_name}: {operation_text}"
        
        if iface:
            iface.messageBar().pushSuccess("FilterMate", message)
    except Exception:
        pass


def show_performance_warning(provider_type: str, feature_count: int):
    """
    Show performance warning for large datasets without PostgreSQL.
    
    Args:
        provider_type (str): Backend type being used
        feature_count (int): Number of features in dataset
    
    Example:
        >>> show_performance_warning('spatialite', 150000)
        # Shows warning about large dataset without PostgreSQL
    """
    try:
        from qgis.utils import iface
        if provider_type == 'postgresql':
            return  # No warning needed for PostgreSQL
        
        backend_name = get_backend_display_name(provider_type)
        
        if feature_count > 100000:
            message = (
                f"Large dataset ({feature_count:,} features) using {backend_name}. "
                "Consider using PostgreSQL for optimal performance."
            )
            if iface:
                iface.messageBar().pushWarning("FilterMate - Performance", message)
        elif feature_count > 50000:
            message = (
                f"Medium-large dataset ({feature_count:,} features) using {backend_name}. "
                "PostgreSQL recommended for better performance."
            )
            if iface:
                iface.messageBar().pushInfo("FilterMate - Performance", message)
    except Exception:
        pass


def show_error_with_context(error_message: str,
                            provider_type: Optional[str] = None,
                            operation: Optional[str] = None):
    """
    Show error message with contextual information.
    
    Args:
        error_message (str): Error description
        provider_type (str, optional): Backend type where error occurred
        operation (str, optional): Operation that failed
    
    Example:
        >>> show_error_with_context("Connection failed", 'postgresql', 'filter')
        # Shows: "FilterMate - 🐘 PostgreSQL: Filter failed - Connection failed"
    """
    try:
        from qgis.utils import iface
        context_parts = []
        
        if provider_type:
            backend_name = get_backend_display_name(provider_type)
            context_parts.append(backend_name)
        
        if operation:
            context_parts.append(operation.title())
        
        if context_parts:
            prefix = " - ".join(context_parts)
            message = f"{prefix}: {error_message}"
        else:
            message = error_message
        
        if iface:
            iface.messageBar().pushCritical("FilterMate", message)
    except Exception:
        pass


def format_backend_summary(provider_counts):
    """
    Format a summary of layers by backend type.
    
    Args:
        provider_counts (dict): Dictionary of provider_type -> count
    
    Returns:
        str: Formatted summary (e.g., "🐘 PostgreSQL: 3, 💾 Spatialite: 2")
    
    Example:
        >>> counts = {'postgresql': 3, 'spatialite': 2}
        >>> format_backend_summary(counts)
        "🐘 PostgreSQL: 3, 💾 Spatialite: 2"
    """
    parts = []
    for provider_type, count in provider_counts.items():
        backend_name = get_backend_display_name(provider_type)
        parts.append(f"{backend_name}: {count}")
    return ", ".join(parts)
